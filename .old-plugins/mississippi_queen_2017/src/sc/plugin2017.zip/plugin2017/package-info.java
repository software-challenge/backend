/**
 * Enthaelt vor allem Klassen, die das Spielgeschehen modellieren. <br>
 * Zentral ist {@link sc.plugin2017.GameState}, das für eine Spielsituation steht. <br>
 * Ausserdem gibt es Klassen für Spieler, das Spielfeld, Spielfeldplättchen, Züge und mehr.
 */
package sc.plugin2017;

